﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FunPlayMovie.Models;

namespace FunPlayMovie.Controllers
{
    public class SessaoController : Controller
    {
        private FunPlayMovieEntities db = new FunPlayMovieEntities();

        //
        // GET: /Sessao/
        [Authorize]

        public ActionResult Index()
        {
            var sessaos = db.Sessaos.Include(s => s.Filme).Include(s => s.Sala);
            return View(sessaos.ToList());
        }

        //
        // GET: /Sessao/Details/5

        public ActionResult Details(int id = 0)
        {
            Sessao sessao = db.Sessaos.Find(id);
            if (sessao == null)
            {
                return HttpNotFound();
            }
            return View(sessao);
        }

        //
        // GET: /Sessao/Create

        public ActionResult Create()
        {
            ViewBag.FilmeId = new SelectList(db.Filmes, "Id", "Titulo");
            ViewBag.SalaId = new SelectList(db.Salas, "Id", "Nome");
            return View();
        }

        //
        // POST: /Sessao/Create

        [HttpPost]
        public ActionResult Create(Sessao sessao)
        {
            if (ModelState.IsValid)
            {
                db.Sessaos.Add(sessao);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.FilmeId = new SelectList(db.Filmes, "Id", "Titulo", sessao.FilmeId);
            ViewBag.SalaId = new SelectList(db.Salas, "Id", "Nome", sessao.SalaId);
            return View(sessao);
        }

        //
        // GET: /Sessao/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Sessao sessao = db.Sessaos.Find(id);
            if (sessao == null)
            {
                return HttpNotFound();
            }
            ViewBag.FilmeId = new SelectList(db.Filmes, "Id", "Titulo", sessao.FilmeId);
            ViewBag.SalaId = new SelectList(db.Salas, "Id", "Nome", sessao.SalaId);
            return View(sessao);
        }

        //
        // POST: /Sessao/Edit/5

        [HttpPost]
        public ActionResult Edit(Sessao sessao)
        {
            if (ModelState.IsValid)
            {
                db.Entry(sessao).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.FilmeId = new SelectList(db.Filmes, "Id", "Titulo", sessao.FilmeId);
            ViewBag.SalaId = new SelectList(db.Salas, "Id", "Nome", sessao.SalaId);
            return View(sessao);
        }

        //
        // GET: /Sessao/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Sessao sessao = db.Sessaos.Find(id);
            if (sessao == null)
            {
                return HttpNotFound();
            }
            return View(sessao);
        }

        //
        // POST: /Sessao/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Sessao sessao = db.Sessaos.Find(id);
            db.Sessaos.Remove(sessao);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}